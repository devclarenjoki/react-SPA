import React, { useState, useEffect } from 'react';

const Countdown = () => {
  const [timeRemaining, setTimeRemaining] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7, 0, 0, 0);
      const time = end.getTime() - now.getTime();
      const days = Math.floor(time / (1000 * 60 * 60 * 24));
      const hours = Math.floor((time / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((time / 1000 / 60) % 60);
      const seconds = Math.floor((time / 1000) % 60);
      setTimeRemaining({ days, hours, minutes, seconds });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="countdown">
      <div className="countdown-timer">
        {Object.entries(timeRemaining).map(([key, value]) => (
          <div key={key} className="countdown-item">
            <span className="countdown-number">{value.toString().padStart(2, '0')}</span>
            <span className="countdown-label">{key.toUpperCase()}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Countdown;
